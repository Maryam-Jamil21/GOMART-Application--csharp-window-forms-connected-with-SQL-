﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.Model
{
    public class SellerModel
    {
        public int SellerID { get; set; }
        public string SellerName { get; set; }
        public string SellerPass { get; set; }
        public int SellerAge { get; set; }
        public string SellerPhone { get; set; }
    }
}
