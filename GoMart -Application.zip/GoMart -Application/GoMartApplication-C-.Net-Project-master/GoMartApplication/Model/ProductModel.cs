﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.Model
{
    public class ProductModel
    {
        public int ProdID { get; set; }
        public string ProdName { get; set; }
        public int ProdCatID { get; set; }
        public decimal ProdPrice { get; set; }
        public int ProdQty { get; set; }
    }
}
