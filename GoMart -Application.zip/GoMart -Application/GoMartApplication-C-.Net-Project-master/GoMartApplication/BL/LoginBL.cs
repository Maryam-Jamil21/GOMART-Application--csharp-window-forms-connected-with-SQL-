﻿using GoMartApplication.DL;
using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.BL
{
    public class LoginBL
    {
        public static bool Login(string role, AdminModel admin, SellerModel seller, DBConnect dbCon)
        {
            if (role == "Admin")
                return LoginDL.AdminLogin(admin, dbCon);

            if (role == "Seller")
                return LoginDL.SellerLogin(seller, dbCon);

            return false;
        }
    }
}
