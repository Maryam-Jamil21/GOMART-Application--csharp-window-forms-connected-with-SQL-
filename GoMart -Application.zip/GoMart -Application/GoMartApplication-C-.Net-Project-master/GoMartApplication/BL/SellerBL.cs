﻿using GoMartApplication.DL;
using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.BL
{
    public class SellerBL
    {
        public static DataTable GetSellers(DBConnect dbCon)
        {
            return SellerDL.GetAllSellers(dbCon);
        }

        public static string AddSeller(SellerModel seller, DBConnect dbCon)
        {
            if (SellerDL.SellerExists(seller.SellerName, dbCon))
                return "Seller name already exists";

            bool success = SellerDL.InsertSeller(seller, dbCon);
            return success ? "Seller inserted successfully" : "Insert failed";
        }

        public static string EditSeller(SellerModel seller, DBConnect dbCon)
        {
            bool success = SellerDL.UpdateSeller(seller, dbCon);
            return success ? "Seller updated successfully" : "Update failed";
        }

        public static string RemoveSeller(int sellerID, DBConnect dbCon)
        {
            bool success = SellerDL.DeleteSeller(sellerID, dbCon);
            return success ? "Seller deleted successfully" : "Delete failed";
        }
    }
}
