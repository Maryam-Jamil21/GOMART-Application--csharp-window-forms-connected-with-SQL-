﻿using GoMartApplication.DL;
using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.BL
{
    public class AdminBL
    {
        public static DataTable GetAdmins(DBConnect dbCon)
        {
            return AdminDL.GetAllAdmins(dbCon);
        }

        public static string AddAdmin(AdminModel admin, DBConnect dbCon)
        {
            if (AdminDL.AdminExists(admin.AdminID, dbCon))
                return "Admin ID already exists";

            bool success = AdminDL.InsertAdmin(admin, dbCon);
            return success ? "Admin Inserted Successfully" : "Insert Failed";
        }

        public static string EditAdmin(AdminModel admin, DBConnect dbCon)
        {
            bool success = AdminDL.UpdateAdmin(admin, dbCon);
            return success ? "Admin Updated Successfully" : "Update Failed";
        }

        public static string RemoveAdmin(string adminID, DBConnect dbCon)
        {
            bool success = AdminDL.DeleteAdmin(adminID, dbCon);
            return success ? "Admin Deleted Successfully" : "Delete Failed";
        }
    }
}
