﻿using GoMartApplication.DL;
using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.BL
{
    public class CategoryBL
    {
        public static DataTable GetCategories(DBConnect dbCon)
        {
            return CategoryDL.GetAllCategories(dbCon);
        }

        public static string AddCategory(CategoryModel cat, DBConnect dbCon)
        {
            if (CategoryDL.CategoryExists(cat.CategoryName, dbCon))
                return "Category Name already exists";

            bool success = CategoryDL.InsertCategory(cat, dbCon);
            return success ? "Category Inserted Successfully" : "Insert Failed";
        }

        public static string EditCategory(CategoryModel cat, DBConnect dbCon)
        {
            if (CategoryDL.CategoryExists(cat.CategoryName, dbCon))
                return "Category Name already exists";

            bool success = CategoryDL.UpdateCategory(cat, dbCon);
            return success ? "Category Updated Successfully" : "Update Failed";
        }

        public static string RemoveCategory(int catID, DBConnect dbCon)
        {
            bool success = CategoryDL.DeleteCategory(catID, dbCon);
            return success ? "Category Deleted Successfully" : "Delete Failed";
        }
    }


}

