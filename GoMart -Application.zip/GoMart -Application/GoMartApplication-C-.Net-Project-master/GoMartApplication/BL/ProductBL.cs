﻿using GoMartApplication.DL;
using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.BL
{
    public class ProductBL
    {
        public static DataTable GetProducts(DBConnect dbCon)
        {
            return ProductDL.GetAllProducts(dbCon);
        }

        public static DataTable GetProductsByCategory(int catID, DBConnect dbCon)
        {
            return ProductDL.GetProductsByCategory(catID, dbCon);
        }

        public static DataTable GetCategories(DBConnect dbCon)
        {
            return ProductDL.GetAllCategories(dbCon);
        }

        public static string AddProduct(ProductModel product, DBConnect dbCon)
        {
            if (ProductDL.ProductExists(product.ProdName, product.ProdCatID, dbCon))
                return "Product already exists in this category";

            return ProductDL.InsertProduct(product, dbCon) ? "Product inserted successfully" : "Insert failed";
        }

        public static string EditProduct(ProductModel product, DBConnect dbCon)
        {
            return ProductDL.UpdateProduct(product, dbCon) ? "Product updated successfully" : "Update failed";
        }

        public static string RemoveProduct(int prodID, DBConnect dbCon)
        {
            return ProductDL.DeleteProduct(prodID, dbCon) ? "Product deleted successfully" : "Delete failed";
        }

    }
}

