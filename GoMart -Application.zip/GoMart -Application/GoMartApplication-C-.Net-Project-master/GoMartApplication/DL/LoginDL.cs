﻿using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.DL
{
    public class LoginDL
    {
        public static bool AdminLogin(AdminModel admin, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand(
                "select top 1 AdminID from tblAdmin where AdminID=@AdminID and Password=@Password",
                dbCon.GetCon());

            cmd.Parameters.AddWithValue("@AdminID", admin.AdminID);
            cmd.Parameters.AddWithValue("@Password", admin.Password);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt.Rows.Count > 0;
        }

        public static bool SellerLogin(SellerModel seller, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand(
                "select top 1 SellerName from tblSeller where SellerName=@SellerName and SellerPass=@SellerPass",
                dbCon.GetCon());

            cmd.Parameters.AddWithValue("@SellerName", seller.SellerName);
            cmd.Parameters.AddWithValue("@SellerPass", seller.SellerPass);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt.Rows.Count > 0;
        }
    }
}
