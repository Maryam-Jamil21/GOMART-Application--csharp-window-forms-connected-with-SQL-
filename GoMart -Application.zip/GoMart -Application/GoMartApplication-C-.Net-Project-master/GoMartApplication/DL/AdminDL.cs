﻿using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.DL
{
    public class AdminDL
    {
        // Get all admins
        public static DataTable GetAllAdmins(DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblAdmin", dbCon.GetCon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        // Check if admin exists
        public static bool AdminExists(string adminID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("SELECT AdminID FROM tblAdmin WHERE AdminID=@ID", dbCon.GetCon());
            cmd.Parameters.AddWithValue("@ID", adminID);
            dbCon.OpenCon();
            var result = cmd.ExecuteScalar();
            dbCon.CloseCon();
            return result != null;
        }

        // Insert admin
        public static bool InsertAdmin(AdminModel admin, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spAddAdmin", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AdminID", admin.AdminID);
            cmd.Parameters.AddWithValue("@Password", admin.Password);
            cmd.Parameters.AddWithValue("@FullName", admin.FullName);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        // Update admin
        public static bool UpdateAdmin(AdminModel admin, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spUpdateAdmin", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AdminID", admin.AdminID);
            cmd.Parameters.AddWithValue("@Password", admin.Password);
            cmd.Parameters.AddWithValue("@FullName", admin.FullName);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        // Delete admin
        public static bool DeleteAdmin(string adminID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spDeleteAdmin", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AdminID", adminID);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }
    }
}
