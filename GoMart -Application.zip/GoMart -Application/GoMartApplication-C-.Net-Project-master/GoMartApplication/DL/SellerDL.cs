﻿using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.DL
{
    public class SellerDL
    {
        public static DataTable GetAllSellers(DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblSeller", dbCon.GetCon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public static bool SellerExists(string sellerName, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("SELECT SellerName FROM tblSeller WHERE SellerName=@Name", dbCon.GetCon());
            cmd.Parameters.AddWithValue("@Name", sellerName);
            dbCon.OpenCon();
            var result = cmd.ExecuteScalar();
            dbCon.CloseCon();
            return result != null;
        }

        public static bool InsertSeller(SellerModel seller, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spSellerInsert", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SellerName", seller.SellerName);
            cmd.Parameters.AddWithValue("@SellerAge", seller.SellerAge);
            cmd.Parameters.AddWithValue("@SellerPhone", seller.SellerPhone);
            cmd.Parameters.AddWithValue("@SellerPass", seller.SellerPass);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool UpdateSeller(SellerModel seller, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spSellerUpdate", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SellerID", seller.SellerID);
            cmd.Parameters.AddWithValue("@SellerName", seller.SellerName);
            cmd.Parameters.AddWithValue("@SellerAge", seller.SellerAge);
            cmd.Parameters.AddWithValue("@SellerPhone", seller.SellerPhone);
            cmd.Parameters.AddWithValue("@SellerPass", seller.SellerPass);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool DeleteSeller(int sellerID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spSellerDelete", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SellerID", sellerID);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }
    }
}
