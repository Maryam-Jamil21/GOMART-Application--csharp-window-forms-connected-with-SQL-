﻿using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoMartApplication.DL
{
    public class ProductDL
    {
        public static DataTable GetAllProducts(DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spGetAllProductList", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public static DataTable GetProductsByCategory(int catID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spGetAllProductList_SearchByCat", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProdCatID", catID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public static DataTable GetAllCategories(DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spGetCategory", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public static bool ProductExists(string prodName, int catID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spCheckDuplicateProduct", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProdName", prodName);
            cmd.Parameters.AddWithValue("@ProdCatID", catID);
            dbCon.OpenCon();
            var result = cmd.ExecuteScalar();
            dbCon.CloseCon();
            return result != null;
        }

        public static bool InsertProduct(ProductModel product, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spInsertProduct", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProdName", product.ProdName);
            cmd.Parameters.AddWithValue("@ProdCatID", product.ProdCatID);
            cmd.Parameters.AddWithValue("@ProdPrice", product.ProdPrice);
            cmd.Parameters.AddWithValue("@ProdQty", product.ProdQty);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool UpdateProduct(ProductModel product, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spUpdateProduct", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProdID", product.ProdID);
            cmd.Parameters.AddWithValue("@ProdName", product.ProdName);
            cmd.Parameters.AddWithValue("@ProdCatID", product.ProdCatID);
            cmd.Parameters.AddWithValue("@ProdPrice", product.ProdPrice);
            cmd.Parameters.AddWithValue("@ProdQty", product.ProdQty);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool DeleteProduct(int prodID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spDeleteProduct", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProdID", prodID);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

    }
}
