﻿using GoMartApplication.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GoMartApplication.BL;

namespace GoMartApplication.DL
{
    public class CategoryDL
    {
        public static DataTable GetAllCategories(DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("SELECT CatID AS CategoryID, CategoryName, CategoryDesc AS CategoryDescription FROM tblCategory", dbCon.GetCon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public static bool InsertCategory(CategoryModel cat, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spCatInsert", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CategoryName", cat.CategoryName);
            cmd.Parameters.AddWithValue("@CategoryDesc", cat.CategoryDesc);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool UpdateCategory(CategoryModel cat, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spCatUpdate", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CatID", cat.CatID);
            cmd.Parameters.AddWithValue("@CategoryName", cat.CategoryName);
            cmd.Parameters.AddWithValue("@CategoryDesc", cat.CategoryDesc);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool DeleteCategory(int catID, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("spCatDelete", dbCon.GetCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CatID", catID);

            dbCon.OpenCon();
            int i = cmd.ExecuteNonQuery();
            dbCon.CloseCon();
            return i > 0;
        }

        public static bool CategoryExists(string catName, DBConnect dbCon)
        {
            SqlCommand cmd = new SqlCommand("SELECT CategoryName FROM tblCategory WHERE CategoryName=@CategoryName", dbCon.GetCon());
            cmd.Parameters.AddWithValue("@CategoryName", catName);
            dbCon.OpenCon();
            var result = cmd.ExecuteScalar();
            dbCon.CloseCon();
            return result != null;
        }
    }
}
