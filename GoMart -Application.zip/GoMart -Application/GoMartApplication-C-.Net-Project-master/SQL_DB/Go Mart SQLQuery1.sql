--CREATE DATABASE GoMartApplication2
--GO

--USE GoMartApplication2
--GO

-- ================= ADMIN TABLE =================
CREATE TABLE tblAdmin
(
    AdminID NVARCHAR(50) PRIMARY KEY,
    [Password] NVARCHAR(50),
    FullName NVARCHAR(50)
)
GO

CREATE PROCEDURE spAddAdmin
(
    @AdminID NVARCHAR(50),
    @Password NVARCHAR(50),
    @FullName NVARCHAR(50)
)
AS
BEGIN
    INSERT INTO tblAdmin VALUES (@AdminID,@Password,@FullName)
END
GO

CREATE PROCEDURE spUpdateAdmin
(
    @AdminID NVARCHAR(50),
    @Password NVARCHAR(50),
    @FullName NVARCHAR(50)
)
AS
BEGIN
    UPDATE tblAdmin
    SET [Password]=@Password, FullName=@FullName
    WHERE AdminID=@AdminID
END
GO

CREATE PROCEDURE spDeleteAdmin
(
    @AdminID NVARCHAR(50)
)
AS
BEGIN
    DELETE FROM tblAdmin WHERE AdminID=@AdminID
END
GO

-- ================= SELLER TABLE =================
CREATE TABLE tblSeller
(
    SellerID INT IDENTITY(1,1) PRIMARY KEY,
    SellerName NVARCHAR(50) UNIQUE,
    SellerAge INT,
    SellerPhone NVARCHAR(50),
    SellerPass NVARCHAR(50)
)
GO

CREATE PROCEDURE spSellerInsert
(
    @SellerName NVARCHAR(50),
    @SellerAge INT,
    @SellerPhone NVARCHAR(50),
    @SellerPass NVARCHAR(50)
)
AS
BEGIN
    INSERT INTO tblSeller
    VALUES (@SellerName,@SellerAge,@SellerPhone,@SellerPass)
END
GO

CREATE PROCEDURE spSellerUpdate   -- typo fixed
(
    @SellerID INT,
    @SellerName NVARCHAR(50),
    @SellerAge INT,
    @SellerPhone NVARCHAR(50),
    @SellerPass NVARCHAR(50)
)
AS
BEGIN
    UPDATE tblSeller
    SET SellerName=@SellerName,
        SellerAge=@SellerAge,
        SellerPhone=@SellerPhone,
        SellerPass=@SellerPass
    WHERE SellerID=@SellerID
END
GO

CREATE PROCEDURE spSellerDelete
(
    @SellerID INT
)
AS
BEGIN
    DELETE FROM tblSeller WHERE SellerID=@SellerID
END
GO

-- ================= CATEGORY TABLE =================
CREATE TABLE tblCategory
(
    CatID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(50),
    CategoryDesc NVARCHAR(50)
)
GO

CREATE PROCEDURE spCatInsert
(
    @CategoryName NVARCHAR(50),
    @CategoryDesc NVARCHAR(50)
)
AS
BEGIN
    INSERT INTO tblCategory VALUES (@CategoryName,@CategoryDesc)
END
GO

CREATE PROCEDURE spCatUpdate
(
    @CatID INT,
    @CategoryName NVARCHAR(50),
    @CategoryDesc NVARCHAR(50)
)
AS
BEGIN
    UPDATE tblCategory
    SET CategoryName=@CategoryName,
        CategoryDesc=@CategoryDesc
    WHERE CatID=@CatID
END
GO

CREATE PROCEDURE spCatDelete
(
    @CatID INT
)
AS
BEGIN
    DELETE FROM tblCategory WHERE CatID=@CatID
END
GO

CREATE PROCEDURE spGetCategory
AS
BEGIN
    SELECT CatID, CategoryName FROM tblCategory ORDER BY CategoryName
END
GO

-- ================= PRODUCT TABLE =================
CREATE TABLE tblProduct
(
    ProdID INT IDENTITY(1,1) PRIMARY KEY,
    ProdName NVARCHAR(50),
    ProdCatID INT,
    ProdPrice DECIMAL(10,2),
    ProdQty INT
)
GO

CREATE PROCEDURE spCheckDuplicateProduct
(
    @ProdName NVARCHAR(50),
    @ProdCatID INT
)
AS
BEGIN
    SELECT ProdName FROM tblProduct
    WHERE ProdName=@ProdName AND ProdCatID=@ProdCatID
END
GO

CREATE PROCEDURE spInsertProduct
(
    @ProdName NVARCHAR(50),
    @ProdCatID INT,
    @ProdPrice DECIMAL(10,2),
    @ProdQty INT
)
AS
BEGIN
    INSERT INTO tblProduct
    VALUES (@ProdName,@ProdCatID,@ProdPrice,@ProdQty)
END
GO

CREATE PROCEDURE spGetAllProductList
AS
BEGIN
    SELECT p.ProdID,p.ProdName,c.CategoryName,
           p.ProdCatID,p.ProdPrice,p.ProdQty
    FROM tblProduct p
    JOIN tblCategory c ON p.ProdCatID=c.CatID
END
GO

CREATE PROCEDURE spUpdateProduct
(
    @ProdID INT,
    @ProdName NVARCHAR(50),
    @ProdCatID INT,
    @ProdPrice DECIMAL(10,2),
    @ProdQty INT
)
AS
BEGIN
    UPDATE tblProduct
    SET ProdName=@ProdName,
        ProdCatID=@ProdCatID,
        ProdPrice=@ProdPrice,
        ProdQty=@ProdQty
    WHERE ProdID=@ProdID
END
GO

CREATE PROCEDURE spDeleteProduct
(
    @ProdID INT
)
AS
BEGIN
    DELETE FROM tblProduct WHERE ProdID=@ProdID
END
GO

-- ================= BILL TABLE =================
CREATE TABLE tblBill
(
    Bill_ID INT PRIMARY KEY,
    SellerID INT,        -- datatype fixed
    SellDate NVARCHAR(50),
    TotalAmt DECIMAL(18,2)
)
GO

CREATE PROCEDURE spInsertBill
(
    @Bill_ID INT,
    @SellerID INT,
    @SellDate NVARCHAR(50),
    @TotalAmt DECIMAL(18,2)
)
AS
BEGIN
    INSERT INTO tblBill
    VALUES (@Bill_ID,@SellerID,@SellDate,@TotalAmt)
END
GO

CREATE PROCEDURE spGetBillList
AS
BEGIN
    SELECT * FROM tblBill ORDER BY Bill_ID DESC
END
GO